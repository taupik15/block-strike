/* Versioned, project-scoped offline cache. Never caches imported maps or remote URLs. */
importScripts('offline-assets.js');
const scope = self.registration.scope;
const prefix = 'block-strike:' + scope + ':';
const cacheName = prefix + OFFLINE_BUILD;
const absolute = path => new URL(path, scope).href;
const shell = OFFLINE_SHELL.map(absolute);
const assets = OFFLINE_ASSETS.map(absolute);
const allowed = new Set([...shell, ...assets]);
function localKey(url) {
 const u = new URL(url); u.search = ''; u.hash = '';
 return allowed.has(u.href) ? u.href : null;
}
async function fetchResource(key) {
 const response = await fetch(key,{cache:'reload',credentials:'same-origin'});
 if (!response.ok || response.status !== 200 || response.redirected ||
     (key !== absolute('index.html') && /text\/html/i.test(response.headers.get('content-type')||''))) throw Error('Resource unavailable: '+key);
 return response;
}
async function store(cache,key){
 const response=await fetchResource(key);await cache.put(key,response.clone());return response;
}
// Only immutable-by-content assets may cross a build boundary. Neither shell JS
// nor imported map data participates. An older cache remains usable until activate.
async function migrateAssets(cache) {
 if(typeof OFFLINE_HASHES==='undefined'||!self.crypto?.subtle)return;
 const names=(await caches.keys()).filter(k=>k.startsWith(prefix)&&k!==cacheName);
 const previous=await Promise.all(names.map(async name=>{const old=await caches.open(name);return {old,keys:new Set((await old.keys()).map(r=>r.url))}}));
 const existing=new Set((await cache.keys()).map(r=>r.url));let next=0;
 await Promise.all(Array.from({length:4},async()=>{
  while(next<assets.length){const i=next++,key=assets[i];if(existing.has(key))continue;
   for(const {old,keys} of previous){if(!keys.has(key))continue;
    try{const response=await old.match(key);if(!response||response.status!==200||response.redirected)continue;
     const bytes=new Uint8Array(await self.crypto.subtle.digest('SHA-256',await response.clone().arrayBuffer()));
     const hash=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
     if(hash!==OFFLINE_HASHES[i])continue;
     await cache.put(key,response);break;
    }catch(_){/* Optional migration: quota/read errors must not prevent install. */}
   }
  }
 }));
}
async function populate(cache,keys,report=()=>{}) {
 let next=0,done=0,failed=0;
 const existing=new Set((await cache.keys()).map(r=>r.url));
 await Promise.all(Array.from({length:4},async()=>{
  while(next<keys.length){const key=keys[next++];try{if(!existing.has(key))await store(cache,key);done++;}catch(_){failed++;}
   if((done+failed)%20===0||done+failed===keys.length)report({done,failed,total:keys.length});
  }
 }));
 return {done,failed,total:keys.length};
}
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(cacheName);const result=await populate(cache,shell);
 if(result.failed)throw Error('Offline shell incomplete');
 try{await migrateAssets(cache)}catch(_){/* Re-prepare missing assets after activation. */}
 // Do not skipWaiting: a running round must not mix two builds.
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 await Promise.all((await caches.keys()).filter(k=>k.startsWith(prefix)&&k!==cacheName).map(k=>caches.delete(k)));
 await self.clients.claim();
})()));
async function respond(req,key){
 const cache=await caches.open(cacheName);let response=await cache.match(key);
 const range=req.headers.get('range');
 if(!response){try{response=await fetchResource(key);}catch(_){return fetch(req);}try{await cache.put(key,response.clone());}catch(_){/* Quota failure must not break online play. */}}
 if(!range)return response;
 const match=/^bytes=(\d*)-(\d*)$/.exec(range);if(!match)return fetch(req);
 const blob=await response.blob(),size=blob.size;
 let first=match[1]?Number(match[1]):Math.max(0,size-Number(match[2]));
 let last=match[1]&&match[2]?Math.min(size-1,Number(match[2])):size-1;
 if(!Number.isSafeInteger(first)||!Number.isSafeInteger(last)||first>last||first>=size||(!match[1]&&!match[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${size}`}});
 return new Response(blob.slice(first,last+1),{status:206,headers:{'Content-Type':response.headers.get('content-type')||'application/octet-stream','Content-Length':String(last-first+1),'Content-Range':`bytes ${first}-${last}/${size}`,'Accept-Ranges':'bytes'}});
}
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 const u=new URL(req.url);let key=localKey(req.url);
 if(req.mode==='navigate'&&(u.href===scope||u.pathname===new URL(scope).pathname&&u.origin===new URL(scope).origin))key=absolute('index.html');
 if(key)event.respondWith(respond(req,key).catch(()=>fetch(req)));
});
let preparing=null;
self.addEventListener('message',event=>{
 const port=event.ports[0];if(!port||!['OFFLINE_STATUS','OFFLINE_PREPARE'].includes(event.data?.type))return;
 const send=data=>{try{port.postMessage(data)}catch(_){}};
 event.waitUntil((async()=>{
  const cache=await caches.open(cacheName);
  if(event.data.type==='OFFLINE_STATUS'){const keys=new Set((await cache.keys()).map(r=>r.url));send({type:'complete',done:allowed.size-[...allowed].filter(k=>!keys.has(k)).length,total:allowed.size,failed:0});return;}
  if(preparing){send({type:'busy'});return;}
  preparing=populate(cache,[...allowed],result=>send({type:'progress',...result}));
  try{send({type:'complete',...await preparing});}finally{preparing=null;}
 })().catch(e=>send({type:'error',message:String(e.message||e)})));
});
